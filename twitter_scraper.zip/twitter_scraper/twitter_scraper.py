import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

class TwitterScraper:
    def __init__(self, url):
        self.url = url
    
    def _get_cookies_and_token(self):
        try:
            # Configure Chrome WebDriver options for headless mode
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            driver = webdriver.Chrome(options=chrome_options)
            driver.get(self.url)

            # Extract Cookies
            cookies = driver.get_cookies()
            cookies_dict = {cookie['name']: cookie['value'] for cookie in cookies}
            cookies_string = "; ".join([f"{k}={v}" for k, v in cookies_dict.items()])

            # Extract 'x-guest-token' from cookies
            x_guest_token = None
            for cookie in cookies:
                if cookie['name'] == 'gt':
                    x_guest_token = cookie['value']
                    break

            return cookies_string, x_guest_token
        except Exception as e:
            print(f"Error occurred while getting cookies and token: {str(e)}")
            return None, None

    def _construct_request(self, cookies_string, x_guest_token, tweet_id):
        try:
            req_url = f"https://api.twitter.com/graphql/7ieDirzd5dipfzjuv3VSmw/TweetResultByRestId?variables=%7B%22tweetId%22%3A%22{tweet_id}%22%2C%22withCommunity%22%3Afalse%2C%22includePromotedContent%22%3Afalse%2C%22withVoice%22%3Afalse%7D&features=%7B%22creator_subscriptions_tweet_preview_api_enabled%22%3Atrue%2C%22communities_web_enable_tweet_community_results_fetch%22%3Atrue%2C%22c9s_tweet_anatomy_moderator_badge_enabled%22%3Atrue%2C%22tweetypie_unmention_optimization_enabled%22%3Atrue%2C%22responsive_web_edit_tweet_api_enabled%22%3Atrue%2C%22graphql_is_translatable_rweb_tweet_is_translatable_enabled%22%3Atrue%2C%22view_counts_everywhere_api_enabled%22%3Atrue%2C%22longform_notetweets_consumption_enabled%22%3Atrue%2C%22responsive_web_twitter_article_tweet_consumption_enabled%22%3Atrue%2C%22tweet_awards_web_tipping_enabled%22%3Afalse%2C%22freedom_of_speech_not_reach_fetch_enabled%22%3Atrue%2C%22standardized_nudges_misinfo%22%3Atrue%2C%22tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled%22%3Atrue%2C%22rweb_video_timestamps_enabled%22%3Atrue%2C%22longform_notetweets_rich_text_read_enabled%22%3Atrue%2C%22longform_notetweets_inline_media_enabled%22%3Atrue%2C%22rweb_tipjar_consumption_enabled%22%3Afalse%2C%22responsive_web_graphql_exclude_directive_enabled%22%3Atrue%2C%22verified_phone_label_enabled%22%3Afalse%2C%22responsive_web_graphql_skip_user_profile_image_extensions_enabled%22%3Afalse%2C%22responsive_web_graphql_timeline_navigation_enabled%22%3Atrue%2C%22responsive_web_enhance_cards_enabled%22%3Afalse%7D&fieldToggles=%7B%22withArticleRichContentState%22%3Atrue%2C%22withArticlePlainText%22%3Afalse%7D"
            
            headers = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9,ar-MA;q=0.8,ar;q=0.7,en-GB;q=0.6,ar-EG;q=0.5",
                "authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                "content-type": "application/json",
                "cookie": cookies_string,
                "origin": "https://twitter.com",
                "referer": "https://twitter.com/",
                "sec-ch-ua": '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "Linux",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
                "x-client-transaction-id": "DN/HnQCcacKdnWvCWtKYXA04D/zTGpXnIuU4PJaKg3VIfZiD+gRn8i2X1Kpt86oB0kDTzQ3meBi+aor1yVQ2gqLMirqxDQ",
                "x-guest-token": x_guest_token,
                "x-twitter-active-user": "yes",
                "x-twitter-client-language": "en" 
            }

            return req_url, headers
        except Exception as e:
            print(f"Error occurred while constructing request: {str(e)}")
            return None, None

    def get_tweet_data(self):
        cookies_string, x_guest_token = self._get_cookies_and_token()
        tweet_id = self.url.split('/')[-1]
        req_url, headers = self._construct_request(cookies_string, x_guest_token, tweet_id)

        # Send request and get tweet data
        response = requests.get(req_url, headers=headers)
        response_data = response.json()
        tweet_result = response_data['data']['tweetResult']['result']['legacy']
        
        return tweet_result