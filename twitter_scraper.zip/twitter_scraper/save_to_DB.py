import mysql.connector
from datetime import datetime

class SaveToDB:
    @staticmethod
    def save_tweet_data_to_db(tweet_result):
        try:
            # Extracted tweet data
            full_text = tweet_result['full_text']
            reply_count = tweet_result['reply_count']
            retweet_count = tweet_result['retweet_count']
            quote_count = tweet_result['quote_count']
            favorite_count = tweet_result['favorite_count']
            created_at = datetime.strptime(tweet_result['created_at'], '%a %b %d %H:%M:%S %z %Y')
            id_str = tweet_result['id_str']

            # Connect to MySQL database
            db_connection = mysql.connector.connect(
                host="",
                user="",
                password="",
                database="TwitterDB"
            )
            cursor = db_connection.cursor()

            # Check if tweet already exists in the database
            cursor.execute("SELECT id_str FROM tweets WHERE id_str = %s", (id_str,))
            existing_tweet = cursor.fetchone()

            if existing_tweet is None:
                # Insert tweet data into MySQL database
                sql = "INSERT INTO tweets (id_str, full_text, reply_count, retweet_count, quote_count, favorite_count, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                val = (id_str, full_text, reply_count, retweet_count, quote_count, favorite_count, created_at)
                cursor.execute(sql, val)

                # Commit changes
                db_connection.commit()

                print("New tweet inserted into the database.")
            else:
                print("Tweet already exists in the database.")

            # Close connection
            cursor.close()
            db_connection.close()

        except Exception as e:
            print("An error occurred:", str(e))