from twitter_scraper import TwitterScraper
from save_to_DB import SaveToDB

class Main:
    @staticmethod
    def run():
        url = 'https://twitter.com/OfficialHenedy/status/1543714010821976066'
        url2 = 'https://twitter.com/binitamshah/status/1776557479507472526'
        scraper = TwitterScraper(url2)
        tweet_data = scraper.get_tweet_data()
        SaveToDB.save_tweet_data_to_db(tweet_data)

if __name__ == "__main__":
    Main.run()